import base64
import datetime
import json

from google.cloud import bigquery
from google.cloud.exceptions import NotFound

# using ga_raw_views_ids.csv dags/flat_table/templates/
TRIGGER_RUN_FLAG = {
    "66721161": True,  # eShop,SG,Web,Other
    "196557704": True,  # HW,SG,Web,Magazine
    "201080470": True,  # HND,SG,Web,Magazine
    "202074098": True,  # SWW,SG,Web,Magazine
    "205988789": True,  # FF,SG,Web,Magazine
    "207383511": True,  # ICON,SG,Web,Magazine
    "207908923": True,  # NUYOU,SG,Web,Magazine
    "207382697": True,  # HBS,SG,Web,Magazine
    "206541403": True,  # PEAK,SG,Web,Magazine
    "196548235": True,  # HZ,SG,Web,Magazine
    "115930016": True,  # UW,SG,Web,Magazine
    "215538005": True,  # CDP,SG,Web,Other
    "186151456": True,  # News Tablet,SG,News Tablet,Other
    "186560078": True,  # STOMP,SG,App,Other
    "179270939": True,  # STOMP,SG,Web,Other
    "219334864": True,  # ThinkChina,SG,Web,Other
    "179605975": True,  # BH,SG,Web,Publication
    "182326428": True,  # TM,SG,Web,Publication
    "181086589": True,  # ST,SG,App,Publication
    "183474061": True,  # BT,SG,App,Publication
    "183612573": True,  # BH,SG,App,Publication
    "181406599": True,  # TNP,SG,App,Publication
    "176640382": True,  # ST,SG,ePaper Web,Publication
    "178817857": True,  # BT,SG,ePaper Web,Publication
    "178690519": True,  # TNP,SG,ePaper Web,Publication
    "180478164": True,  # ZB SG,SG,ePaper Web,Publication
    "180506312": True,  # WB,SG,ePaper Web,Publication
    "180386354": True,  # SM,SG,ePaper Web,Publication
    "176616349": True,  # ZB SG,SG,Web,Publication
    "176655527": True,  # ZB CN,CN,Web,Publication
    "180472617": True,  # WB,SG,Web,Publication
    "181124549": True,  # SM,SG,Web,Publication
    "181045799": True,  # ZB SG,SG,App,Publication
    "180978299": True,  # ZB CN,CN,App,Publication
}


def main(event, context):

    pubsub_message = base64.b64decode(event["data"]).decode("utf-8")
    resourceName = json.loads(pubsub_message)["protoPayload"]["resourceName"]
    ga_view_id = resourceName.split("/")[3]
    visit_date = resourceName.split("_")[-1]

    if TRIGGER_RUN_FLAG[ga_view_id] is False:
        return

    # for dev only: copy prd-msa-ga360bq hw data to dev-msa-ga360bq
    client = bigquery.Client()

    src_dataset = client.dataset(project="prd-msa-ga360bq", dataset_id=ga_view_id)
    dest_dataset = client.dataset(project="dev-msa-ga360bq", dataset_id=ga_view_id)

    src_table = src_dataset.table("ga_sessions_" + visit_date)
    dest_table = dest_dataset.table("ga_sessions_" + visit_date)

    try:
        client.get_table(dest_table)
        print("Table already exist, skip")

    except NotFound:
        client.copy_table(src_table, dest_table)
        print(
            "Prd to Dev Copy for view {} on {} data at {}".format(
                ga_view_id, visit_date, datetime.datetime.now().isoformat()
            )
        )
