import base64
import csv
import json
import os

import requests
from dotenv import load_dotenv
from google.auth.transport.requests import Request
from google.oauth2 import id_token

load_dotenv()

IAM_SCOPE = "https://www.googleapis.com/auth/iam"
OAUTH_TOKEN_URI = "https://www.googleapis.com/oauth2/v4/token"
# If you are using the stable API, set this value to False
# For more info about Airflow APIs see https://cloud.google.com/composer/docs/access-airflow-api
USE_EXPERIMENTAL_API = False

# using dag_name in ga_view_id_dag_name_mapping.csv
TRIGGER_RUN_FLAG = {
    "eshop_web_flat_table_dag": True,
    "uw_web_flat_table_dag": False,
    "zb_sg_web_flat_table_dag": True,
    "st_epaper_web_flat_table_dag": True,
    "st_web_flat_table_dag": True,
    "zb_cn_web_flat_table_dag": True,
    "tnp_epaper_web_flat_table_dag": True,
    "tnp_web_flat_table_dag": True,
    "bt_epaper_web_flat_table_dag": True,
    "bt_web_flat_table_dag": True,
    "stomp_web_flat_table_dag": True,
    "bh_web_flat_table_dag": True,
    "bh_epaper_web_flat_table_dag": True,
    "sm_epaper_web_flat_table_dag": True,
    "wb_web_flat_table_dag": True,
    "zb_sg_epaper_web_flat_table_dag": True,
    "wb_epaper_web_flat_table_dag": True,
    "zb_cn_app_flat_table_dag": True,
    "zb_cn_epaper_app_flat_table_dag": True,
    "zb_sg_app_flat_table_dag": True,
    "zb_sg_epaper_app_flat_table_dag": True,
    "wb_epaper_app_flat_table_dag": True,
    "sm_epaper_app_flat_table_dag": True,
    "st_app_flat_table_dag": True,
    "st_epaper_app_flat_table_dag": True,
    "sm_web_flat_table_dag": True,
    "tnp_app_flat_table_dag": True,
    "tnp_epaper_app_flat_table_dag": True,
    "tm_web_flat_table_dag": True,
    "tm_epaper_web_flat_table_dag": True,
    "bt_app_flat_table_dag": True,
    "bt_epaper_app_flat_table_dag": True,
    "bh_app_flat_table_dag": True,
    "bh_epaper_app_flat_table_dag": True,
    "news_tablet_news_tablet_flat_table_dag": True,
    "bh_news_tablet_flat_table_dag": True,
    "tm_news_tablet_flat_table_dag": True,
    "st_news_tablet_flat_table_dag": True,
    "bt_news_tablet_flat_table_dag": True,
    "zb_sg_news_tablet_flat_table_dag": True,
    "wb_news_tablet_flat_table_dag": True,
    "sm_news_tablet_flat_table_dag": True,
    "hw_news_tablet_flat_table_dag": True,
    "uw_news_tablet_flat_table_dag": True,
    "hz_web_flat_table_dag": True,
    "stomp_app_flat_table_dag": True,
    "hw_web_flat_table_dag": True,
    "hnd_web_flat_table_dag": True,
    "sww_web_flat_table_dag": True,
    "ff_web_flat_table_dag": True,
    "peak_web_flat_table_dag": True,
    "hbs_web_flat_table_dag": True,
    "icon_web_flat_table_dag": True,
    "nuyou_web_flat_table_dag": True,
    "cdp_web_flat_table_dag": True,
    "thinkchina_web_flat_table_dag": True,
}

DAG_NAME_LOOKUP = {}
with open("ga_view_id_dag_name_mapping.csv", "r") as fd:
    csv_reader = csv.reader(fd)
    # skip header row
    next(csv_reader)

    for row in csv_reader:
        ga_view_id, dag_name = row

        if ga_view_id in DAG_NAME_LOOKUP:
            DAG_NAME_LOOKUP[ga_view_id].append(dag_name)

        else:
            DAG_NAME_LOOKUP[ga_view_id] = [dag_name]


def main(event, context):
    pubsub_message = base64.b64decode(event["data"]).decode("utf-8")
    resourceName = json.loads(pubsub_message)["protoPayload"]["resourceName"]
    ga_view_id = resourceName.split("/")[3]
    visit_date = resourceName.split("_")[-1]

    for dag_name in DAG_NAME_LOOKUP[ga_view_id]:
        if TRIGGER_RUN_FLAG[dag_name] is False:
            continue

        trigger_dag(dag_name, {"ga_view_id": ga_view_id, "visit_date": visit_date})


def trigger_dag(dag_name, conf):
    """Makes a POST request to the Composer DAG Trigger API

    When called via Google Cloud Functions (GCF),
    data and context are Background function parameters.

    For more info, refer to
    https://cloud.google.com/functions/docs/writing/background#functions_background_parameters-python

    To call this function from a Python script, omit the ``context`` argument
    and pass in a non-null value for the ``data`` argument.
    """

    # Fill in with your Composer info here
    # Navigate to your webserver's login page and get this from the URL
    # Or use the script found at
    # https://github.com/GoogleCloudPlatform/python-docs-samples/blob/master/composer/rest/get_client_id.py

    client_id = os.getenv("CLIENT_ID")

    # This should be part of your webserver's URL:
    # {tenant-project-id}.appspot.com
    webserver_id = "o29f553727a729047p-tp"
    # The name of the DAG you wish to trigger

    if USE_EXPERIMENTAL_API:
        endpoint = f"api/experimental/dags/{dag_name}/dag_runs"
        json_data = {"conf": conf, "replace_microseconds": "false"}
    else:
        endpoint = f"api/v1/dags/{dag_name}/dagRuns"
        json_data = {"conf": conf}
    webserver_url = "https://" + webserver_id + ".appspot.com/" + endpoint
    # Make a POST request to IAP which then Triggers the DAG
    dag_resp = make_iap_request(webserver_url, client_id, method="POST", json=json_data)
    print(dag_resp)


# This code is copied from
# https://github.com/GoogleCloudPlatform/python-docs-samples/blob/master/iap/make_iap_request.py
# START COPIED IAP CODE
def make_iap_request(url, client_id, method="GET", **kwargs):
    """Makes a request to an application protected by Identity-Aware Proxy.
    Args:
      url: The Identity-Aware Proxy-protected URL to fetch.
      client_id: The client ID used by Identity-Aware Proxy.
      method: The request method to use
              ('GET', 'OPTIONS', 'HEAD', 'POST', 'PUT', 'PATCH', 'DELETE')
      **kwargs: Any of the parameters defined for the request function:
                https://github.com/requests/requests/blob/master/requests/api.py
                If no timeout is provided, it is set to 90 by default.
    Returns:
      The page body, or raises an exception if the page couldn't be retrieved.
    """
    # Set the default timeout, if missing
    if "timeout" not in kwargs:
        kwargs["timeout"] = 90

    # Obtain an OpenID Connect (OIDC) token from metadata server or using service
    # account.
    google_open_id_connect_token = id_token.fetch_id_token(Request(), client_id)

    # Fetch the Identity-Aware Proxy-protected URL, including an
    # Authorization header containing "Bearer " followed by a
    # Google-issued OpenID Connect token for the service account.
    resp = requests.request(
        method,
        url,
        headers={"Authorization": "Bearer {}".format(google_open_id_connect_token)},
        **kwargs,
    )
    if resp.status_code == 403:
        raise Exception(
            "Service account does not have permission to "
            "access the IAP-protected application."
        )
    elif resp.status_code != 200:
        raise Exception(
            "Bad response from application: {!r} / {!r} / {!r}".format(
                resp.status_code, resp.headers, resp.text
            )
        )
    else:
        return resp.text


# END COPIED IAP CODE
